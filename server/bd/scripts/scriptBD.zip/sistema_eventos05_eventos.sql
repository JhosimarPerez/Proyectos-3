-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: sistema_eventos05
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `eventos`
--

DROP TABLE IF EXISTS `eventos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eventos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `categoria_evento_id` int DEFAULT NULL,
  `titulo` varchar(100) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `descripcion` text,
  `organizadores` varchar(255) DEFAULT NULL,
  `ubicacion` varchar(255) DEFAULT NULL,
  `fecha_hora` datetime DEFAULT NULL,
  `precio_base` decimal(10,2) DEFAULT NULL,
  `cupo_disponible` int DEFAULT NULL,
  `es_evento_virtual` tinyint(1) DEFAULT '0',
  `url_transmision` varchar(255) DEFAULT NULL,
  `plataforma_virtual` varchar(100) DEFAULT NULL,
  `fecha_creacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_modificacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `activo` tinyint(1) DEFAULT '1',
  `latitud` blob COMMENT 'Coordenada de latitud almacenada como BLOB',
  `longitud` blob COMMENT 'Coordenada de longitud almacenada como BLOB',
  `rutaImagen` varchar(255) DEFAULT NULL COMMENT 'Ruta para almacenar imágenes relacionadas',
  `prioridadImagen` int DEFAULT NULL COMMENT 'Prioridad de la imagen (1: prioritario, 2: no prioritario)',
  PRIMARY KEY (`id`),
  KEY `categoria_evento_id` (`categoria_evento_id`),
  CONSTRAINT `eventos_ibfk_1` FOREIGN KEY (`categoria_evento_id`) REFERENCES `categoriaeventos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `eventos_chk_1` CHECK ((`precio_base` >= 0)),
  CONSTRAINT `eventos_chk_2` CHECK ((`cupo_disponible` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eventos`
--

LOCK TABLES `eventos` WRITE;
/*!40000 ALTER TABLE `eventos` DISABLE KEYS */;
INSERT INTO `eventos` VALUES (4,1,'testing','http://localhost:3001/api/categorias','testing',NULL,'testing','2024-11-03 04:12:00',1.00,12,0,NULL,NULL,'2024-11-06 08:10:55','2024-11-06 08:44:19',0,NULL,NULL,NULL,NULL),(5,1,'aaaa','http://Univalle.edu','aaaa','aaaa','aaaa','2024-11-04 21:54:00',666.00,6666,0,'http://Univalle.edu','meet','2024-11-06 08:54:09','2024-11-27 09:40:21',0,NULL,NULL,NULL,NULL),(6,2,'DIANA','http://Univalle.edu','DIANA',NULL,'DIANA','2024-11-09 12:05:00',123.00,123,0,NULL,NULL,'2024-11-06 15:04:10','2024-11-06 15:14:04',0,NULL,NULL,NULL,NULL),(7,1,'a','http://Univalle.edu','a',NULL,'23','2024-11-11 23:23:00',1.00,1,0,NULL,NULL,'2024-11-11 08:31:08','2024-11-11 09:22:16',0,NULL,NULL,NULL,NULL),(8,3,'aa','http://Univalle.edu','aaaa','aaaa','Estadio Nacional BOLIVIA UPDATE','1212-12-13 01:49:48',12.00,0,1,'','','2024-11-27 10:16:39','2024-11-30 07:10:22',0,NULL,NULL,NULL,NULL),(9,1,'bbbbbbbbbbbb','http://Univalle.edu','bbbbbbbbbbbb','aaaa','Estadio Nacional BOLIVIA UPDATE','1212-12-12 16:44:36',12.00,10,1,'','','2024-11-27 11:00:11','2024-11-27 11:00:23',0,NULL,NULL,NULL,NULL),(10,1,'123','http://Univalle.edu','123','123','Estadio Nacional BOLIVIA','1212-12-12 16:44:36',123.00,2,1,'','','2024-11-28 17:45:08','2024-11-30 07:10:27',0,NULL,NULL,NULL,NULL),(11,2,'qwerty','http://Univalle.edu','qwerty','qwerty','Estadio Nacional BOLIVIA','1212-12-12 16:44:36',1.00,1,1,'','','2024-11-28 17:48:51','2024-11-30 07:12:32',0,NULL,NULL,NULL,NULL),(13,1,'Concierto Rock Fest,,,,','http://Univalle.edu','Concierto Rock Fest....','RockFest Org','Estadio Nacional BOLIVIA UPDATE','2024-12-12 20:12:00',12.00,0,0,'','','2024-11-30 06:40:28','2024-11-30 09:20:23',0,_binary '-17.413874',_binary '-66.246064',NULL,NULL),(15,1,'Concierto Rock Fest','http://Univalle.edu','http://Univalle.edu','RockFest Org','Estadio Nacional BOLIVIA UPDATE','2024-12-12 16:12:00',123.00,0,0,'','','2024-11-30 07:27:10','2024-11-30 09:20:30',0,_binary '-17.398149',_binary '-66.176026',NULL,NULL),(21,1,'Concierto Rock Fest','http://Univalle.edu','qwert','RockFest Org','Estadio Nacional BOLIVIA UPDATE','2024-12-12 16:12:00',123.00,113,1,'','','2024-11-30 09:55:52','2024-12-02 10:36:57',0,_binary '-17.105707',_binary '-67.741957',NULL,2),(22,1,'Concierto Rock Fest..............','http://Univalle.edu','Concierto Rock Fest.................','RockFest Org','Estadio Nacional BOLIVIA UPDATE','2024-12-12 20:12:00',123.00,108,1,'','','2024-11-30 11:09:12','2024-12-02 15:04:03',0,_binary '-17.373003',_binary '-66.226794',NULL,1),(23,1,'Concierto Rock Fest','http://Univalle.edu','qwer','RockFest Org','Estadio Nacional BOLIVIA UPDATE','2024-12-12 20:12:00',12.00,21,1,'','','2024-11-30 12:04:13','2024-11-30 12:04:25',0,_binary '-17.393951',_binary '-66.218559',NULL,1),(50,1,'Concierto Rock Fest','http://Univalle.edusssss','Concierto Rock Fest','Concierto Rock Fest','Concierto Rock Fest','2024-12-12 12:12:00',123.00,123,0,'http://Univalle.edu','','2024-12-05 04:23:58','2024-12-05 05:50:51',0,_binary '-17.393201759350926',_binary '-66.16001129150392','/uploads/1733372638345-Captura de pantalla 2024-12-04 225424.png',1),(51,1,'testtest','http://Univalle.edu','test','test','test','2024-12-12 12:12:00',123.00,123,0,'','','2024-12-05 04:35:32','2024-12-05 23:32:59',0,_binary '-17.397559113082018',_binary '-66.16275787353517','/uploads/1733373332107-Captura de pantalla 2024-11-28 203310.png',0),(54,1,'facebook','http://Univalle.edu','facebook','facebook','facebook','2024-12-12 12:12:00',123.00,123,0,'','','2024-12-05 04:56:29','2024-12-05 23:33:15',0,_binary '-17.392038687334527',_binary '-66.14576339721681','/uploads/1733375644120-Captura de pantalla 2024-11-28 211246.png',0),(55,1,'Fest Univalle','http://Univalle.edus','Fest','Fest','Fest','2024-12-12 12:12:00',123.00,123,0,'','','2024-12-05 05:43:20','2024-12-05 23:33:13',0,_binary '-17.394397584470337',_binary '-66.16202831268312','/uploads/1733377400365-Captura de pantalla 2024-12-05 014159.png',1),(56,1,'Trabajar','http://Univalle.edu','Trabajar','Trabajar','Trabajar','2024-12-12 12:12:00',123.00,123,0,'http://Univalle.edu','','2024-12-05 07:02:52','2024-12-05 23:33:10',0,_binary '-17.39139981519255',_binary '-66.15932464599611','/uploads/1733382172915-Captura de pantalla 2024-11-27 013608.png',1),(57,1,'Facebook.com','http://Univalle.edus','Facebook.com','Facebook.com','Facebook.com','2024-12-20 12:12:00',123.00,123,0,'http://Univalle.edu','','2024-12-05 08:25:18','2024-12-05 23:33:08',0,_binary '-17.412104720393266',_binary '-66.15911006927492','/uploads/1733387118826-Captura de pantalla 2024-11-27 040339.png',0),(58,1,'Concierto Rock Fest','http://Univalle.edu','Concierto Rock Fest','Concierto Rock Fest','Estadio Nacional BOLIVIA UPDATE','2024-12-12 12:12:00',123.00,123,0,'http://Univalle.edu','','2024-12-05 16:59:09','2024-12-05 23:33:07',0,_binary '-17.393398333503487',_binary '-66.15674972534181','/uploads/1733417949652-Captura de pantalla 2024-12-02 051600.png',1),(59,1,'Concierto Rock Fest','http://Univalle.edu','Concierto Rock Fest','RockFest Org','Concierto Rock Fest','2024-12-12 12:12:00',10.00,11,0,'','','2024-12-05 17:07:07','2024-12-05 23:33:05',0,_binary '-17.390547981365884',_binary '-66.15674972534181','/uploads/1733418427673-Captura de pantalla 2024-12-03 121725.png',1),(60,1,'Concierto Rock Fest','http://Univalle.edu','Concierto Rock Fest','Concierto Rock Fest','Concierto Rock Fest','2024-12-12 12:12:00',123.00,26,0,'','','2024-12-05 17:13:07','2024-12-05 23:33:02',0,_binary '-17.391367052907114',_binary '-66.16601943969728','/uploads/1733418787379-Captura de pantalla 2024-11-27 040339.png',1),(61,1,'Concierto Rock Fest asd','http://Univalle.edus','Concierto Rock Fest asd','Concierto Rock Fest asd','Concierto Rock Fest asd','2024-12-12 12:12:00',123.00,123,0,'http://Univalle.edu','','2024-12-05 18:15:48','2024-12-05 23:32:56',0,_binary '-17.38907364335022',_binary '-66.15880966186525',NULL,1),(62,1,'Concierto Rock Fest','http://Univalle.edu','Concierto Rock Fest','Concierto Rock Fest','Concierto Rock Fest','2024-12-12 12:12:00',12.00,123,0,'http://Univalle.edus','','2024-12-05 18:26:25','2024-12-05 23:32:54',0,_binary '-17.342117958744943',_binary '-66.15554809570314',NULL,1),(63,1,'Concierto Rock Fest','http://Univalle.edu','Concierto Rock Fest','Concierto Rock Fest','123','2024-12-12 12:12:00',121.00,123,0,'http://Univalle.edu','','2024-12-05 18:45:10','2024-12-05 23:32:52',0,_binary '-17.391760204944383',_binary '-66.16395950317384',NULL,1),(64,1,'Concierto Rock Fest','http://Univalle.edus','Concierto Rock Fest','Concierto Rock Fest','Concierto Rock Fest','2024-12-12 12:12:00',123.00,123,0,'http://Univalle.edu','','2024-12-05 18:49:03','2024-12-05 23:32:50',0,_binary '-17.413218525945492',_binary '-66.10473632812501','/uploads/1733424543781-Captura de pantalla 2024-12-03 121725.png',1),(65,3,'Univalle','http://Univalle.edu','Univalle','Univalle','Univalle','2024-12-12 12:12:00',10.00,299,0,'http://Univalle.edu','','2024-12-05 23:36:28','2024-12-05 23:45:48',0,_binary '-17.406666634018343',_binary '-66.13460540771486','/uploads/1733441788552-images.jpeg',0),(66,3,'Univalle','http://Univalle.edu','Univalle event','Univalle','Tiquipaya','2024-12-12 12:12:00',10.00,100,0,'http://streaming.techconf.com','','2024-12-06 00:17:20','2024-12-06 00:17:20',1,_binary '-17.39061350622429',_binary '-66.15674972534181','/uploads/1733444240598-images (1).jpeg',1),(67,3,'Youtube','http://techconf.com','Youtube','Youtube','Cochabamba','2024-12-12 12:12:00',100.00,10,0,'','','2024-12-06 00:18:39','2024-12-06 00:18:39',1,_binary '-17.392841372439275',_binary '-66.15983963012697','/uploads/1733444319891-images.jpeg',0),(68,1,'Concierto Rock Fest','http://Univalle.edu','Concierto Rock Fest','RockFest Org','Cochabamba','2024-12-12 12:12:00',50.00,520,0,'http://Univalle.edu','','2024-12-06 00:28:22','2024-12-06 00:28:22',1,_binary '-17.392841372439275',_binary '-66.16344451904298','/uploads/1733444902398-images (1).jpeg',1);
/*!40000 ALTER TABLE `eventos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-05 21:20:45
